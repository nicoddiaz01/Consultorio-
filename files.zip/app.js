/* =====================================================================
   CONSULTORIO KINÉSICO — app.js
   Todo el estado vive en localStorage bajo la clave "consultorio_v1"
   ===================================================================== */

const STORAGE_KEY = 'consultorio_v1';

/* ---------- Valores normativos de ROM (referencia estándar) ----------
   Fuente: rangos de referencia habituales en goniometría clínica
   (AAOS / Norkin & White). Sirven como punto de partida: se pueden
   ajustar por paciente si el kinesiólogo lo considera necesario. */
const ROM_NORMATIVOS = {
  "Hombro": [
    {mov:"Flexión", normal:180},
    {mov:"Extensión", normal:60},
    {mov:"Abducción", normal:180},
    {mov:"Rotación interna", normal:70},
    {mov:"Rotación externa", normal:90},
  ],
  "Codo": [
    {mov:"Flexión", normal:145},
    {mov:"Pronación", normal:80},
    {mov:"Supinación", normal:80},
  ],
  "Muñeca": [
    {mov:"Flexión", normal:80},
    {mov:"Extensión", normal:70},
    {mov:"Desviación radial", normal:20},
    {mov:"Desviación cubital", normal:30},
  ],
  "Cadera": [
    {mov:"Flexión", normal:120},
    {mov:"Extensión", normal:20},
    {mov:"Abducción", normal:45},
    {mov:"Aducción", normal:25},
    {mov:"Rotación interna", normal:35},
    {mov:"Rotación externa", normal:45},
  ],
  "Rodilla": [
    {mov:"Flexión", normal:135},
    {mov:"Extensión", normal:0},
  ],
  "Tobillo": [
    {mov:"Flexión dorsal", normal:20},
    {mov:"Flexión plantar", normal:50},
    {mov:"Inversión", normal:35},
    {mov:"Eversión", normal:15},
  ],
  "Columna cervical": [
    {mov:"Flexión", normal:50},
    {mov:"Extensión", normal:60},
    {mov:"Rotación", normal:80},
    {mov:"Inclinación lateral", normal:45},
  ],
  "Columna lumbar": [
    {mov:"Flexión", normal:60},
    {mov:"Extensión", normal:25},
    {mov:"Inclinación lateral", normal:25},
  ],
};

/* ---------- Biblioteca de ejercicios de ejemplo ----------
   Cada ejercicio tiene 4 ejes de clasificación (puede tener varios
   valores por eje). El usuario puede agregar los suyos desde la UI. */
const EJERCICIOS_EJEMPLO = [
  {id:'ex1', nombre:'Press militar con mancuernas', zona:['Miembro superior'], articulacion:['Hombro'], musculo:['Deltoides','Trapecio'], gesto:['Empuje vertical'], desc:'Sentado o de pie, empuje de mancuernas por sobre la cabeza.'},
  {id:'ex2', nombre:'Remo con banda elástica', zona:['Miembro superior'], articulacion:['Hombro','Escápula'], musculo:['Dorsal ancho','Romboides'], gesto:['Tracción horizontal'], desc:'Tracción de banda hacia el abdomen, codos cerca del cuerpo.'},
  {id:'ex3', nombre:'Rotación externa con banda', zona:['Miembro superior'], articulacion:['Hombro'], musculo:['Infraespinoso','Redondo menor'], gesto:['Rotación'], desc:'Codo a 90°, rotar el antebrazo alejándolo del cuerpo.'},
  {id:'ex4', nombre:'Sentadilla goblet', zona:['Miembro inferior'], articulacion:['Cadera','Rodilla','Tobillo'], musculo:['Cuádriceps','Glúteo mayor'], gesto:['Flexo-extensión'], desc:'Sentadilla sosteniendo una pesa contra el pecho.'},
  {id:'ex5', nombre:'Puente de glúteo unilateral', zona:['Miembro inferior','Tronco'], articulacion:['Cadera'], musculo:['Glúteo mayor','Isquiotibiales'], gesto:['Extensión de cadera'], desc:'Decúbito dorsal, elevar la pelvis apoyando un solo pie.'},
  {id:'ex6', nombre:'Step-up con escalón', zona:['Miembro inferior'], articulacion:['Cadera','Rodilla'], musculo:['Cuádriceps','Glúteo medio'], gesto:['Flexo-extensión','Control de equilibrio'], desc:'Subir y bajar un escalón controlando la rodilla.'},
  {id:'ex7', nombre:'Plancha abdominal', zona:['Tronco'], articulacion:['Columna lumbar'], musculo:['Recto abdominal','Transverso'], gesto:['Estabilización'], desc:'Apoyo en antebrazos y pies, manteniendo el tronco alineado.'},
  {id:'ex8', nombre:'Bird-dog', zona:['Tronco'], articulacion:['Columna lumbar','Cadera','Hombro'], musculo:['Erectores espinales','Glúteo mayor'], gesto:['Estabilización','Control motor'], desc:'En cuadrupedia, extender brazo y pierna opuestos.'},
  {id:'ex9', nombre:'Elevación de talones (gemelos)', zona:['Miembro inferior'], articulacion:['Tobillo'], musculo:['Gastrocnemio','Sóleo'], gesto:['Flexión plantar'], desc:'De pie, elevar los talones sobre las puntas de los pies.'},
  {id:'ex10', nombre:'Movilidad cervical activa', zona:['Cabeza y cuello'], articulacion:['Columna cervical'], musculo:['Trapecio superior','Esternocleidomastoideo'], gesto:['Movilidad articular'], desc:'Flexo-extensión y rotaciones activas suaves de cuello.'},
];

/* ---------- Cuestionarios de ejemplo (autoreportados) ----------
   Cada cuestionario es una lista de preguntas con escala 0-4 (tipo
   Likert), pensado para escalas funcionales habituales en kinesiología. */
const CUESTIONARIOS_PLANTILLA = {
  'DASH (simplificado)': [
    'Abrir un frasco con tapa a rosca apretada',
    'Hacer tareas pesadas del hogar',
    'Cargar una bolsa de compras',
    'Lavarse la espalda',
    'Dificultad para dormir por el dolor en hombro/brazo/mano',
  ],
  'Funcional de Rodilla': [
    'Subir escaleras',
    'Bajar escaleras',
    'Ponerse en cuclillas',
    'Caminar en superficie irregular',
    'Correr en línea recta',
  ],
  'Funcional Lumbar (Oswestry simplificado)': [
    'Intensidad del dolor en reposo',
    'Cuidado personal (vestirse, lavarse)',
    'Levantar objetos',
    'Caminar',
    'Estar sentado',
    'Estar de pie',
    'Dormir',
  ],
};

/* ---------- Estado global ---------- */
let state = {
  pacientes: [],
  ejercicios: [],
  activePatientId: null,
};

function loadState(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw){
      const parsed = JSON.parse(raw);
      state.pacientes = parsed.pacientes || [];
      state.ejercicios = parsed.ejercicios || [];
      state.activePatientId = parsed.activePatientId || null;
    }
  }catch(e){
    console.error('Error leyendo datos guardados', e);
  }
  if(!state.ejercicios || state.ejercicios.length === 0){
    state.ejercicios = JSON.parse(JSON.stringify(EJERCICIOS_EJEMPLO));
  }
}

function saveState(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function uid(prefix){
  return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);
}

function getActivePatient(){
  return state.pacientes.find(p => p.id === state.activePatientId) || null;
}

function fmtDate(iso){
  const d = new Date(iso);
  return d.toLocaleDateString('es-AR', {day:'2-digit', month:'2-digit', year:'numeric'});
}
function fmtDateShort(iso){
  const d = new Date(iso);
  return d.toLocaleDateString('es-AR', {day:'2-digit', month:'short'});
}
function todayISO(){
  return new Date().toISOString().slice(0,10);
}
function initials(name){
  return (name||'').trim().split(/\s+/).slice(0,2).map(w => w.length ? w[0].toUpperCase() : '').join('');
}

function toast(msg, danger=false){
  const host = document.getElementById('toastHost');
  const el = document.createElement('div');
  el.className = 'toast' + (danger ? ' danger':'');
  el.textContent = msg;
  host.appendChild(el);
  setTimeout(()=>{ el.remove(); }, 2800);
}

function escapeHtml(str){
  if(str===undefined||str===null) return '';
  return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

/* =====================================================================
   MODELO DE PACIENTE
   ===================================================================== */
function nuevoPaciente(datos){
  return {
    id: uid('pac'),
    nombre: datos.nombre || '',
    dni: datos.dni || '',
    fechaNacimiento: datos.fechaNacimiento || '',
    telefono: datos.telefono || '',
    diagnostico: datos.diagnostico || '',
    lesion: datos.lesion || '',
    objetivos: datos.objetivos || '',
    antecedentes: datos.antecedentes || '',
    fechaIngreso: todayISO(),
    rom: [],            // {fecha, evaluaciones:[{zona,mov,normal,lado,valor}]}
    fuerza: [],         // {fecha, ejercicioORmusculo, kgIzq, kgDer}
    dolor: [],          // {fecha, valor (0-10), nota}
    cuestionarios: [],  // {fecha, nombre, respuestas:[0-4...], total}
    rutina: [],         // [{ejercicioId, series, reps, carga, notas}]
    sesiones: [],       // {fecha, notas, ejerciciosRealizados:[ids], dolorSesion}
  };
}

/* =====================================================================
   NAVEGACIÓN / RENDER PRINCIPAL
   ===================================================================== */
const VIEWS = ['pacientes','ficha','rom','fuerza','dolor','cuestionarios','rutina','sesiones','ejercicios'];
const VIEW_TITLES = {
  pacientes: ['Consultorio', 'Pacientes'],
  ficha: ['Paciente', 'Ficha'],
  rom: ['Evaluación', 'Rangos de movimiento'],
  fuerza: ['Evaluación', 'Fuerza muscular'],
  dolor: ['Seguimiento', 'Evolución del dolor'],
  cuestionarios: ['Seguimiento', 'Cuestionarios autoreportados'],
  rutina: ['Tratamiento', 'Rutina de ejercicios'],
  sesiones: ['Tratamiento', 'Sesiones'],
  ejercicios: ['Biblioteca', 'Ejercicios'],
};

function goToView(name){
  if(!VIEWS.includes(name)) name = 'pacientes';
  const navBtn = document.querySelector(`.nav-item[data-view="${name}"]`);
  const needsPatient = navBtn ? navBtn.dataset.needsPatient : null;
  if(needsPatient && !getActivePatient()){
    toast('Primero elegí un paciente', true);
    name = 'pacientes';
  }
  VIEWS.forEach(v => {
    document.getElementById('view-'+v).hidden = (v !== name);
  });
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === name);
  });
  const [eyebrow, title] = VIEW_TITLES[name];
  document.getElementById('topbarEyebrow').textContent = eyebrow;
  document.getElementById('topbarTitle').textContent = title;
  document.getElementById('sidebar').classList.remove('open');

  renderView(name);
  location.hash = name;
}

function renderView(name){
  const renderers = {
    pacientes: renderPacientes,
    ficha: renderFicha,
    rom: renderRom,
    fuerza: renderFuerza,
    dolor: renderDolor,
    cuestionarios: renderCuestionarios,
    rutina: renderRutina,
    sesiones: renderSesiones,
    ejercicios: renderEjercicios,
  };
  renderers[name] && renderers[name]();
}

function refreshSidebarPatient(){
  const p = getActivePatient();
  const pill = document.getElementById('activePatientPill');
  if(p){
    pill.hidden = false;
    document.getElementById('activePatientName').textContent = p.nombre;
  }else{
    pill.hidden = true;
  }
}

function setTopbarActions(html){
  document.getElementById('topbarActions').innerHTML = html;
}

/* =====================================================================
   VISTA: PACIENTES
   ===================================================================== */
function renderPacientes(){
  setTopbarActions(`<button class="btn btn-primary" id="btnNuevoPaciente">+ Nuevo paciente</button>`);
  const root = document.getElementById('view-pacientes');

  if(state.pacientes.length === 0){
    root.innerHTML = `
      <div class="empty-state card">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#8aa0a8" stroke-width="1.6"><circle cx="12" cy="8" r="3.6"/><path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6"/></svg>
        <h3>Todavía no agregaste pacientes</h3>
        <p>Creá tu primer paciente para empezar a registrar evaluaciones, rutinas y sesiones.</p>
      </div>`;
  }else{
    const ordenados = [...state.pacientes].sort((a,b)=> a.nombre.localeCompare(b.nombre));
    root.innerHTML = `<div class="patient-list">` + ordenados.map(p => `
      <div class="patient-card" data-id="${p.id}">
        <div class="patient-card-main">
          <div class="patient-avatar">${escapeHtml(initials(p.nombre))}</div>
          <div>
            <div class="patient-card-name">${escapeHtml(p.nombre)}</div>
            <div class="patient-card-meta">${escapeHtml(p.diagnostico || 'Sin diagnóstico registrado')}</div>
          </div>
        </div>
        <div style="display:flex;gap:8px;align-items:center;">
          <span class="badge badge-petrol">Ingreso ${fmtDateShort(p.fechaIngreso)}</span>
          <button class="btn btn-sm" data-action="abrir" data-id="${p.id}">Abrir</button>
        </div>
      </div>
    `).join('') + `</div>`;
  }

  root.querySelectorAll('.patient-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if(e.target.closest('button')) return;
      seleccionarPaciente(card.dataset.id);
    });
  });
  root.querySelectorAll('[data-action="abrir"]').forEach(btn => {
    btn.addEventListener('click', () => seleccionarPaciente(btn.dataset.id));
  });

  document.getElementById('btnNuevoPaciente').addEventListener('click', abrirModalNuevoPaciente);
}

function seleccionarPaciente(id){
  state.activePatientId = id;
  saveState();
  refreshSidebarPatient();
  goToView('ficha');
}

function abrirModalNuevoPaciente(){
  openModal(`
    <div class="modal-head">
      <h3>Nuevo paciente</h3>
      <button class="modal-close" data-close>&times;</button>
    </div>
    <div class="modal-body">
      <div class="field"><label>Nombre y apellido *</label><input type="text" id="np_nombre" placeholder="Ej: María Gómez"></div>
      <div class="grid-2">
        <div class="field"><label>DNI</label><input type="text" id="np_dni"></div>
        <div class="field"><label>Fecha de nacimiento</label><input type="date" id="np_fnac"></div>
      </div>
      <div class="field"><label>Teléfono</label><input type="text" id="np_tel"></div>
      <div class="field"><label>Diagnóstico / motivo de consulta</label><input type="text" id="np_diag" placeholder="Ej: Tendinopatía rotuliana"></div>
    </div>
    <div class="modal-foot">
      <button class="btn" data-close>Cancelar</button>
      <button class="btn btn-primary" id="np_guardar">Crear paciente</button>
    </div>
  `);
  document.getElementById('np_guardar').addEventListener('click', () => {
    const nombre = document.getElementById('np_nombre').value.trim();
    if(!nombre){ toast('El nombre es obligatorio', true); return; }
    const p = nuevoPaciente({
      nombre,
      dni: document.getElementById('np_dni').value.trim(),
      fechaNacimiento: document.getElementById('np_fnac').value,
      telefono: document.getElementById('np_tel').value.trim(),
      diagnostico: document.getElementById('np_diag').value.trim(),
    });
    state.pacientes.push(p);
    state.activePatientId = p.id;
    saveState();
    closeModal();
    refreshSidebarPatient();
    toast('Paciente creado');
    goToView('ficha');
  });
}

/* =====================================================================
   VISTA: FICHA DEL PACIENTE
   ===================================================================== */
function renderFicha(){
  const p = getActivePatient();
  if(!p) return;
  setTopbarActions(`<button class="btn btn-danger" id="btnEliminarPaciente">Eliminar paciente</button>`);
  const root = document.getElementById('view-ficha');
  const edad = p.fechaNacimiento ? calcularEdad(p.fechaNacimiento) : null;

  root.innerHTML = `
    <div class="card section-gap">
      <div class="card-head">
        <h3>Datos personales</h3>
        <button class="btn btn-sm" id="btnEditarDatos">Editar</button>
      </div>
      <div class="card-pad">
        <dl class="kv">
          <dt>Nombre</dt><dd>${escapeHtml(p.nombre)}</dd>
          <dt>DNI</dt><dd>${escapeHtml(p.dni)||'—'}</dd>
          <dt>Edad</dt><dd>${edad!==null ? edad+' años' : '—'}</dd>
          <dt>Teléfono</dt><dd>${escapeHtml(p.telefono)||'—'}</dd>
          <dt>Ingreso</dt><dd>${fmtDate(p.fechaIngreso)}</dd>
        </dl>
      </div>
    </div>

    <div class="card section-gap">
      <div class="card-head">
        <h3>Diagnóstico y objetivos</h3>
        <button class="btn btn-sm" id="btnEditarClinico">Editar</button>
      </div>
      <div class="card-pad">
        <dl class="kv">
          <dt>Diagnóstico</dt><dd>${escapeHtml(p.diagnostico)||'—'}</dd>
          <dt>Lesión</dt><dd>${escapeHtml(p.lesion)||'—'}</dd>
          <dt>Objetivos</dt><dd>${escapeHtml(p.objetivos)||'—'}</dd>
          <dt>Antecedentes</dt><dd>${escapeHtml(p.antecedentes)||'—'}</dd>
        </dl>
      </div>
    </div>

    <div class="grid-3">
      <div class="stat-tile"><div class="num">${p.sesiones.length}</div><div class="lbl">Sesiones registradas</div></div>
      <div class="stat-tile"><div class="num">${p.rom.length}</div><div class="lbl">Evaluaciones de ROM</div></div>
      <div class="stat-tile"><div class="num">${p.rutina.length}</div><div class="lbl">Ejercicios en rutina</div></div>
    </div>
  `;

  document.getElementById('btnEditarDatos').addEventListener('click', () => abrirModalEditarDatos(p));
  document.getElementById('btnEditarClinico').addEventListener('click', () => abrirModalEditarClinico(p));
  document.getElementById('btnEliminarPaciente').addEventListener('click', () => confirmarEliminarPaciente(p));
}

function calcularEdad(fechaISO){
  const hoy = new Date();
  const nac = new Date(fechaISO);
  let edad = hoy.getFullYear() - nac.getFullYear();
  const m = hoy.getMonth() - nac.getMonth();
  if(m < 0 || (m===0 && hoy.getDate() < nac.getDate())) edad--;
  return edad;
}

function abrirModalEditarDatos(p){
  openModal(`
    <div class="modal-head"><h3>Editar datos personales</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="field"><label>Nombre y apellido</label><input type="text" id="ed_nombre" value="${escapeHtml(p.nombre)}"></div>
      <div class="grid-2">
        <div class="field"><label>DNI</label><input type="text" id="ed_dni" value="${escapeHtml(p.dni)}"></div>
        <div class="field"><label>Fecha de nacimiento</label><input type="date" id="ed_fnac" value="${p.fechaNacimiento||''}"></div>
      </div>
      <div class="field"><label>Teléfono</label><input type="text" id="ed_tel" value="${escapeHtml(p.telefono)}"></div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="ed_guardar">Guardar</button></div>
  `);
  document.getElementById('ed_guardar').addEventListener('click', () => {
    p.nombre = document.getElementById('ed_nombre').value.trim() || p.nombre;
    p.dni = document.getElementById('ed_dni').value.trim();
    p.fechaNacimiento = document.getElementById('ed_fnac').value;
    p.telefono = document.getElementById('ed_tel').value.trim();
    saveState(); closeModal(); refreshSidebarPatient(); renderFicha();
    toast('Datos actualizados');
  });
}

function abrirModalEditarClinico(p){
  openModal(`
    <div class="modal-head"><h3>Editar diagnóstico y objetivos</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="field"><label>Diagnóstico</label><input type="text" id="ec_diag" value="${escapeHtml(p.diagnostico)}"></div>
      <div class="field"><label>Lesión</label><input type="text" id="ec_lesion" value="${escapeHtml(p.lesion)}"></div>
      <div class="field"><label>Objetivos del tratamiento</label><textarea id="ec_obj">${escapeHtml(p.objetivos)}</textarea></div>
      <div class="field"><label>Antecedentes médicos</label><textarea id="ec_antec">${escapeHtml(p.antecedentes)}</textarea></div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="ec_guardar">Guardar</button></div>
  `);
  document.getElementById('ec_guardar').addEventListener('click', () => {
    p.diagnostico = document.getElementById('ec_diag').value.trim();
    p.lesion = document.getElementById('ec_lesion').value.trim();
    p.objetivos = document.getElementById('ec_obj').value.trim();
    p.antecedentes = document.getElementById('ec_antec').value.trim();
    saveState(); closeModal(); renderFicha();
    toast('Datos clínicos actualizados');
  });
}

function confirmarEliminarPaciente(p){
  openModal(`
    <div class="modal-head"><h3>Eliminar paciente</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <p>Vas a eliminar a <strong>${escapeHtml(p.nombre)}</strong> y todos sus datos (evaluaciones, rutina, sesiones). Esta acción no se puede deshacer.</p>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-danger" id="del_confirmar">Eliminar definitivamente</button></div>
  `);
  document.getElementById('del_confirmar').addEventListener('click', () => {
    state.pacientes = state.pacientes.filter(x => x.id !== p.id);
    if(state.activePatientId === p.id) state.activePatientId = null;
    saveState(); closeModal(); refreshSidebarPatient();
    toast('Paciente eliminado');
    goToView('pacientes');
  });
}

/* =====================================================================
   VISTA: EVALUACIÓN ROM (con semáforo)
   ===================================================================== */
function calcularSemaforo(valor, normal){
  if(valor === '' || valor === null || valor === undefined || isNaN(valor)) return 'gris';
  if(normal === 0) return valor <= 5 ? 'verde' : (valor <= 10 ? 'amarillo' : 'rojo');
  const pct = (Number(valor) / normal) * 100;
  if(pct >= 90) return 'verde';
  if(pct >= 70) return 'amarillo';
  return 'rojo';
}
const SEMAFORO_LABEL = {verde:'Normal', amarillo:'Restricción leve', rojo:'Restricción marcada', gris:'Sin dato'};

function renderRom(){
  const p = getActivePatient();
  if(!p) return;
  setTopbarActions(`<button class="btn btn-primary" id="btnNuevaEvalRom">+ Nueva evaluación</button>`);
  const root = document.getElementById('view-rom');

  let historialHtml = '';
  if(p.rom.length === 0){
    historialHtml = `<div class="empty-state card">
      <h3>Sin evaluaciones de ROM</h3>
      <p>Registrá la primera evaluación para empezar a ver el semáforo de movilidad de ${escapeHtml(p.nombre)}.</p>
    </div>`;
  }else{
    const ordenadas = [...p.rom].sort((a,b)=> new Date(b.fecha)-new Date(a.fecha));
    historialHtml = ordenadas.map((ev) => {
      const idxOriginal = p.rom.findIndex(x => x.id === ev.id);
      const counts = {verde:0,amarillo:0,rojo:0,gris:0};
      ev.evaluaciones.forEach(e => counts[calcularSemaforo(e.valor, e.normal)]++);
      return `
      <div class="card section-gap">
        <div class="card-head">
          <div>
            <h3>Evaluación del ${fmtDate(ev.fecha)}</h3>
            <div style="margin-top:6px;display:flex;gap:6px;">
              <span class="badge badge-sage">${counts.verde} normal</span>
              <span class="badge badge-amber">${counts.amarillo} leve</span>
              <span class="badge badge-terra">${counts.rojo} marcada</span>
            </div>
          </div>
          <button class="btn btn-sm btn-danger" data-action="del-rom" data-idx="${idxOriginal}">Eliminar</button>
        </div>
        <div class="card-pad">
          <div class="rom-row head">
            <div>Movimiento</div><div>Normal</div><div>Lado Izq / Der</div><div>Estado</div>
          </div>
          ${ev.evaluaciones.map(e => `
            <div class="rom-row">
              <div>
                <div class="rom-move-name">${escapeHtml(e.zona)} — ${escapeHtml(e.mov)}</div>
              </div>
              <div class="rom-move-normal mono">${e.normal}°</div>
              <div class="mono">${e.valor!==''&&e.valor!==null ? e.valor+'°' : '—'} ${e.lado?('('+e.lado+')'):''}</div>
              <div class="semaforo ${calcularSemaforo(e.valor, e.normal)}">${e.valor!==''&&e.valor!==null ? Math.round((e.valor/ (e.normal||1))*100)+'%' : '·'}</div>
            </div>
          `).join('')}
        </div>
      </div>`;
    }).join('');
  }

  root.innerHTML = `
    <div class="card section-gap card-pad" style="display:flex;gap:18px;align-items:center;flex-wrap:wrap;">
      <div style="display:flex;align-items:center;gap:8px;"><span class="semaforo verde" style="width:22px;height:22px;font-size:0;"></span><span style="font-size:13px;color:var(--ink-soft);">≥ 90% del valor normal</span></div>
      <div style="display:flex;align-items:center;gap:8px;"><span class="semaforo amarillo" style="width:22px;height:22px;font-size:0;"></span><span style="font-size:13px;color:var(--ink-soft);">70–89% del valor normal</span></div>
      <div style="display:flex;align-items:center;gap:8px;"><span class="semaforo rojo" style="width:22px;height:22px;font-size:0;"></span><span style="font-size:13px;color:var(--ink-soft);">&lt; 70% del valor normal</span></div>
    </div>
    ${historialHtml}
  `;

  root.querySelectorAll('[data-action="del-rom"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const i = Number(btn.dataset.idx);
      p.rom.splice(i,1);
      saveState(); renderRom(); toast('Evaluación eliminada');
    });
  });

  document.getElementById('btnNuevaEvalRom').addEventListener('click', () => abrirModalNuevaEvalRom(p));
}

function abrirModalNuevaEvalRom(p){
  const zonas = Object.keys(ROM_NORMATIVOS);
  openModal(`
    <div class="modal-head"><h3>Nueva evaluación de ROM</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="field">
        <label>Elegí las articulaciones a evaluar</label>
        <div class="checklist" id="rom_zonas">
          ${zonas.map(z => `<label><input type="checkbox" value="${z}"> ${z}</label>`).join('')}
        </div>
      </div>
      <div class="field"><label>Fecha</label><input type="date" id="rom_fecha" value="${todayISO()}"></div>
      <div id="rom_detalle"></div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="rom_continuar">Continuar</button></div>
  `);

  document.getElementById('rom_continuar').addEventListener('click', () => {
    const seleccionadas = Array.from(document.querySelectorAll('#rom_zonas input:checked')).map(i=>i.value);
    if(seleccionadas.length === 0){ toast('Elegí al menos una articulación', true); return; }
    const fecha = document.getElementById('rom_fecha').value || todayISO();
    abrirModalCompletarRom(p, seleccionadas, fecha);
  });
}

function abrirModalCompletarRom(p, zonas, fecha){
  const filas = [];
  zonas.forEach(z => {
    ROM_NORMATIVOS[z].forEach(m => {
      filas.push({zona:z, mov:m.mov, normal:m.normal});
    });
  });
  openModal(`
    <div class="modal-head"><h3>Completar valores (en grados)</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <p class="field-hint" style="margin-bottom:12px;">Ingresá el valor medido por lado. Dejá vacío si no aplica (ej. movimientos de columna).</p>
      ${filas.map((f,i) => `
        <div class="field" style="border-bottom:1px solid var(--line);padding-bottom:10px;margin-bottom:10px;">
          <label>${escapeHtml(f.zona)} — ${escapeHtml(f.mov)} <span class="field-hint">(normal: ${f.normal}°)</span></label>
          <div class="grid-2">
            <input type="number" placeholder="Izquierdo" data-i="${i}" data-lado="Izq" class="rom-input">
            <input type="number" placeholder="Derecho" data-i="${i}" data-lado="Der" class="rom-input">
          </div>
        </div>
      `).join('')}
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="rom_guardar">Guardar evaluación</button></div>
  `);

  document.getElementById('rom_guardar').addEventListener('click', () => {
    const evaluaciones = [];
    filas.forEach((f, i) => {
      ['Izq','Der'].forEach(lado => {
        const input = document.querySelector(`.rom-input[data-i="${i}"][data-lado="${lado}"]`);
        const val = input.value;
        if(val !== ''){
          evaluaciones.push({zona:f.zona, mov:f.mov, normal:f.normal, lado, valor:Number(val)});
        }
      });
    });
    if(evaluaciones.length === 0){ toast('Ingresá al menos un valor', true); return; }
    p.rom.push({id: uid('rom'), fecha, evaluaciones});
    saveState(); closeModal(); renderRom();
    toast('Evaluación de ROM guardada');
  });
}

/* =====================================================================
   VISTA: FUERZA (dinamometría kg + LSI) con gráfico
   ===================================================================== */
let chartFuerza = null;
let chartDolor = null;

function calcularLSI(izq, der){
  // LSI = (lado afectado / lado no afectado) * 100. Tomamos el menor como
  // "afectado" por defecto, ya que es el uso clínico más común.
  if(!izq || !der || izq===0 || der===0) return null;
  const menor = Math.min(izq, der);
  const mayor = Math.max(izq, der);
  return Math.round((menor/mayor)*1000)/10;
}

function renderFuerza(){
  const p = getActivePatient();
  if(!p) return;
  setTopbarActions(`<button class="btn btn-primary" id="btnNuevoRegFuerza">+ Nuevo registro</button>`);
  const root = document.getElementById('view-fuerza');

  if(p.fuerza.length === 0){
    root.innerHTML = `<div class="empty-state card">
      <h3>Sin registros de fuerza</h3>
      <p>Registrá mediciones de dinamómetro (kg) por lado para ver la evolución y el LSI.</p>
    </div>`;
    document.getElementById('btnNuevoRegFuerza').addEventListener('click', () => abrirModalNuevoRegFuerza(p));
    return;
  }

  const ordenados = [...p.fuerza].sort((a,b)=> new Date(a.fecha)-new Date(b.fecha));
  const grupos = {};
  ordenados.forEach(r => { (grupos[r.ejercicio] = grupos[r.ejercicio]||[]).push(r); });

  root.innerHTML = `
    <div class="card section-gap card-pad">
      <h3 style="margin-bottom:14px;">Evolución de fuerza (kg)</h3>
      <div class="chart-wrap"><canvas id="canvasFuerza"></canvas></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>Registros</h3></div>
      <div class="card-pad">
        <table>
          <tr><th>Fecha</th><th>Ejercicio/Músculo</th><th>Izq (kg)</th><th>Der (kg)</th><th>LSI</th><th></th></tr>
          ${[...p.fuerza].sort((a,b)=>new Date(b.fecha)-new Date(a.fecha)).map((r) => {
            const lsi = calcularLSI(r.kgIzq, r.kgDer);
            const idxOriginal = p.fuerza.findIndex(x => x.id === r.id);
            return `<tr>
              <td>${fmtDate(r.fecha)}</td>
              <td>${escapeHtml(r.ejercicio)}</td>
              <td class="mono">${r.kgIzq!==null && r.kgIzq!==undefined ? r.kgIzq : '—'}</td>
              <td class="mono">${r.kgDer!==null && r.kgDer!==undefined ? r.kgDer : '—'}</td>
              <td>${lsi!==null ? `<span class="badge ${lsi>=90?'badge-sage':lsi>=80?'badge-amber':'badge-terra'}">${lsi}%</span>` : '—'}</td>
              <td><button class="btn btn-sm btn-danger" data-action="del-fuerza" data-idx="${idxOriginal}">Eliminar</button></td>
            </tr>`;
          }).join('')}
        </table>
      </div>
    </div>
  `;

  // Gráfico: una línea por ejercicio/músculo registrado, con izq y der
  const labels = [...new Set(ordenados.map(r => r.fecha))].sort();
  const ejercicioKeys = Object.keys(grupos);
  const palette = ['#1b4965','#4f9a6f','#d9952f','#bd4338','#7a5fb5','#2a7f8c'];
  const datasets = [];
  ejercicioKeys.forEach((ej, idx) => {
    const color = palette[idx % palette.length];
    const dataIzq = labels.map(l => {
      const reg = grupos[ej].find(r => r.fecha === l);
      return reg ? reg.kgIzq : null;
    });
    const dataDer = labels.map(l => {
      const reg = grupos[ej].find(r => r.fecha === l);
      return reg ? reg.kgDer : null;
    });
    datasets.push({label:ej+' (Izq)', data:dataIzq, borderColor:color, backgroundColor:color, borderDash:[5,3], spanGaps:true, tension:.25});
    datasets.push({label:ej+' (Der)', data:dataDer, borderColor:color, backgroundColor:color, spanGaps:true, tension:.25});
  });

  if(chartFuerza) chartFuerza.destroy();
  chartFuerza = new Chart(document.getElementById('canvasFuerza'), {
    type:'line',
    data:{ labels: labels.map(fmtDateShort), datasets },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{legend:{position:'bottom', labels:{boxWidth:12,font:{size:11}}}},
      scales:{ y:{ title:{display:true,text:'kg'}, beginAtZero:true } }
    }
  });

  root.querySelectorAll('[data-action="del-fuerza"]').forEach(btn => {
    btn.addEventListener('click', () => {
      p.fuerza.splice(Number(btn.dataset.idx),1);
      saveState(); renderFuerza(); toast('Registro eliminado');
    });
  });
  document.getElementById('btnNuevoRegFuerza').addEventListener('click', () => abrirModalNuevoRegFuerza(p));
}

function abrirModalNuevoRegFuerza(p){
  openModal(`
    <div class="modal-head"><h3>Nuevo registro de fuerza</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="field"><label>Fecha</label><input type="date" id="fz_fecha" value="${todayISO()}"></div>
      <div class="field"><label>Ejercicio o músculo evaluado</label><input type="text" id="fz_nombre" placeholder="Ej: Cuádriceps / Press de pierna"></div>
      <div class="grid-2">
        <div class="field"><label>Lado izquierdo (kg)</label><input type="number" step="0.1" id="fz_izq"></div>
        <div class="field"><label>Lado derecho (kg)</label><input type="number" step="0.1" id="fz_der"></div>
      </div>
      <div class="field-hint">El LSI (Índice de Simetría de Miembros) se calcula automáticamente como lado menor / lado mayor.</div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="fz_guardar">Guardar</button></div>
  `);
  document.getElementById('fz_guardar').addEventListener('click', () => {
    const nombre = document.getElementById('fz_nombre').value.trim();
    if(!nombre){ toast('Indicá el ejercicio o músculo', true); return; }
    const kgIzq = document.getElementById('fz_izq').value;
    const kgDer = document.getElementById('fz_der').value;
    p.fuerza.push({
      id: uid('fz'),
      fecha: document.getElementById('fz_fecha').value || todayISO(),
      ejercicio: nombre,
      kgIzq: kgIzq===''?null:Number(kgIzq),
      kgDer: kgDer===''?null:Number(kgDer),
    });
    saveState(); closeModal(); renderFuerza();
    toast('Registro de fuerza guardado');
  });
}

/* =====================================================================
   VISTA: DOLOR (evolución)
   ===================================================================== */
function renderDolor(){
  const p = getActivePatient();
  if(!p) return;
  setTopbarActions(`<button class="btn btn-primary" id="btnNuevoRegDolor">+ Registrar dolor</button>`);
  const root = document.getElementById('view-dolor');

  if(p.dolor.length === 0){
    root.innerHTML = `<div class="empty-state card">
      <h3>Sin registros de dolor</h3>
      <p>Registrá el nivel de dolor (escala 0–10) en cada control para ver la evolución.</p>
    </div>`;
    document.getElementById('btnNuevoRegDolor').addEventListener('click', () => abrirModalNuevoRegDolor(p));
    return;
  }

  const ordenados = [...p.dolor].sort((a,b)=> new Date(a.fecha)-new Date(b.fecha));
  root.innerHTML = `
    <div class="card section-gap card-pad">
      <h3 style="margin-bottom:14px;">Evolución del dolor (EVA 0–10)</h3>
      <div class="chart-wrap"><canvas id="canvasDolor"></canvas></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>Registros</h3></div>
      <div class="card-pad">
        <table>
          <tr><th>Fecha</th><th>Nivel</th><th>Nota</th><th></th></tr>
          ${[...p.dolor].sort((a,b)=>new Date(b.fecha)-new Date(a.fecha)).map((r) => {
            const idxOriginal = p.dolor.findIndex(x => x.id === r.id);
            const cls = r.valor<=3?'badge-sage':r.valor<=6?'badge-amber':'badge-terra';
            return `<tr>
              <td>${fmtDate(r.fecha)}</td>
              <td><span class="badge ${cls}">${r.valor}/10</span></td>
              <td>${escapeHtml(r.nota)||'—'}</td>
              <td><button class="btn btn-sm btn-danger" data-action="del-dolor" data-idx="${idxOriginal}">Eliminar</button></td>
            </tr>`;
          }).join('')}
        </table>
      </div>
    </div>
  `;

  if(chartDolor) chartDolor.destroy();
  chartDolor = new Chart(document.getElementById('canvasDolor'), {
    type:'line',
    data:{
      labels: ordenados.map(r=>fmtDateShort(r.fecha)),
      datasets:[{
        label:'Dolor (0-10)', data: ordenados.map(r=>r.valor),
        borderColor:'#bd4338', backgroundColor:'rgba(189,67,56,.12)', fill:true, tension:.3, pointRadius:4,
      }]
    },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{ y:{ min:0, max:10, ticks:{stepSize:1} } }
    }
  });

  root.querySelectorAll('[data-action="del-dolor"]').forEach(btn => {
    btn.addEventListener('click', () => {
      p.dolor.splice(Number(btn.dataset.idx),1);
      saveState(); renderDolor(); toast('Registro eliminado');
    });
  });
  document.getElementById('btnNuevoRegDolor').addEventListener('click', () => abrirModalNuevoRegDolor(p));
}

function abrirModalNuevoRegDolor(p){
  openModal(`
    <div class="modal-head"><h3>Registrar dolor</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="field"><label>Fecha</label><input type="date" id="dl_fecha" value="${todayISO()}"></div>
      <div class="field">
        <label>Nivel de dolor (EVA): <span id="dl_valor_display">5</span>/10</label>
        <input type="range" min="0" max="10" value="5" id="dl_valor" style="width:100%;">
      </div>
      <div class="field"><label>Nota (opcional)</label><input type="text" id="dl_nota" placeholder="Ej: dolor al subir escaleras"></div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="dl_guardar">Guardar</button></div>
  `);
  document.getElementById('dl_valor').addEventListener('input', (e) => {
    document.getElementById('dl_valor_display').textContent = e.target.value;
  });
  document.getElementById('dl_guardar').addEventListener('click', () => {
    p.dolor.push({
      id: uid('dl'),
      fecha: document.getElementById('dl_fecha').value || todayISO(),
      valor: Number(document.getElementById('dl_valor').value),
      nota: document.getElementById('dl_nota').value.trim(),
    });
    saveState(); closeModal(); renderDolor();
    toast('Dolor registrado');
  });
}

/* =====================================================================
   VISTA: CUESTIONARIOS AUTOREPORTADOS
   ===================================================================== */
function renderCuestionarios(){
  const p = getActivePatient();
  if(!p) return;
  setTopbarActions(`<button class="btn btn-primary" id="btnNuevoCuest">+ Aplicar cuestionario</button>`);
  const root = document.getElementById('view-cuestionarios');

  if(p.cuestionarios.length === 0){
    root.innerHTML = `<div class="empty-state card">
      <h3>Sin cuestionarios aplicados</h3>
      <p>Aplicá un cuestionario autoreportado para registrar la percepción funcional del paciente.</p>
    </div>`;
  }else{
    const ordenados = [...p.cuestionarios].sort((a,b)=> new Date(b.fecha)-new Date(a.fecha));
    root.innerHTML = ordenados.map((c) => {
      const idxOriginal = p.cuestionarios.findIndex(x => x.id === c.id);
      const max = c.preguntas.length * 4;
      const pct = Math.round((c.total/max)*100);
      return `
      <div class="card section-gap">
        <div class="card-head">
          <div>
            <h3>${escapeHtml(c.nombre)}</h3>
            <div class="field-hint">${fmtDate(c.fecha)}</div>
          </div>
          <div style="display:flex;gap:8px;align-items:center;">
            <span class="badge badge-petrol">${c.total}/${max} pts (${pct}%)</span>
            <button class="btn btn-sm btn-danger" data-action="del-cuest" data-idx="${idxOriginal}">Eliminar</button>
          </div>
        </div>
        <div class="card-pad">
          ${c.preguntas.map((preg,i) => `
            <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--line);font-size:13.5px;">
              <span>${escapeHtml(preg)}</span>
              <span class="mono badge-neutral badge" style="margin-left:10px;">${c.respuestas[i]}/4</span>
            </div>
          `).join('')}
        </div>
      </div>`;
    }).join('');
  }

  root.querySelectorAll('[data-action="del-cuest"]').forEach(btn => {
    btn.addEventListener('click', () => {
      p.cuestionarios.splice(Number(btn.dataset.idx),1);
      saveState(); renderCuestionarios(); toast('Cuestionario eliminado');
    });
  });

  document.getElementById('btnNuevoCuest').addEventListener('click', () => abrirModalElegirCuestionario(p));
}

function abrirModalElegirCuestionario(p){
  const nombres = Object.keys(CUESTIONARIOS_PLANTILLA);
  openModal(`
    <div class="modal-head"><h3>Elegir cuestionario</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="field">
        <label>Plantilla</label>
        <select id="cu_plantilla">
          ${nombres.map(n => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('')}
        </select>
      </div>
      <div class="field"><label>Fecha</label><input type="date" id="cu_fecha" value="${todayISO()}"></div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="cu_continuar">Continuar</button></div>
  `);
  document.getElementById('cu_continuar').addEventListener('click', () => {
    const nombre = document.getElementById('cu_plantilla').value;
    const fecha = document.getElementById('cu_fecha').value || todayISO();
    abrirModalResponderCuestionario(p, nombre, fecha);
  });
}

function abrirModalResponderCuestionario(p, nombre, fecha){
  const preguntas = CUESTIONARIOS_PLANTILLA[nombre];
  const escalaLabels = ['Sin dificultad','Leve','Moderada','Severa','Incapacitante'];
  openModal(`
    <div class="modal-head"><h3>${escapeHtml(nombre)}</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <p class="field-hint" style="margin-bottom:12px;">Escala: 0 = sin dificultad · 4 = incapacitante</p>
      ${preguntas.map((preg,i) => `
        <div class="field">
          <label>${escapeHtml(preg)}</label>
          <select class="cu-resp" data-i="${i}">
            ${escalaLabels.map((l,v) => `<option value="${v}">${v} — ${l}</option>`).join('')}
          </select>
        </div>
      `).join('')}
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="cu_guardar">Guardar respuestas</button></div>
  `);
  document.getElementById('cu_guardar').addEventListener('click', () => {
    const respuestas = preguntas.map((_,i) => Number(document.querySelector(`.cu-resp[data-i="${i}"]`).value));
    const total = respuestas.reduce((a,b)=>a+b,0);
    p.cuestionarios.push({id: uid('cu'), fecha, nombre, preguntas, respuestas, total});
    saveState(); closeModal(); renderCuestionarios();
    toast('Cuestionario guardado');
  });
}

/* =====================================================================
   VISTA: BIBLIOTECA DE EJERCICIOS (solapas Zona/Articulación/Músculo/Gesto)
   ===================================================================== */
let ejerciciosFiltro = { eje:'zona', valor: null };

function getEjesUnicos(eje){
  const vals = new Set();
  state.ejercicios.forEach(ex => (ex[eje]||[]).forEach(v => vals.add(v)));
  return Array.from(vals).sort();
}

function renderEjercicios(){
  setTopbarActions(`<button class="btn btn-primary" id="btnNuevoEjercicio">+ Agregar ejercicio</button>`);
  const root = document.getElementById('view-ejercicios');

  const ejes = [
    {key:'zona', label:'Zona'},
    {key:'articulacion', label:'Articulación'},
    {key:'musculo', label:'Músculo'},
    {key:'gesto', label:'Gesto'},
  ];

  const valoresDelEje = getEjesUnicos(ejerciciosFiltro.eje);
  if(ejerciciosFiltro.valor && !valoresDelEje.includes(ejerciciosFiltro.valor)) ejerciciosFiltro.valor = null;

  const filtrados = ejerciciosFiltro.valor
    ? state.ejercicios.filter(ex => (ex[ejerciciosFiltro.eje]||[]).includes(ejerciciosFiltro.valor))
    : state.ejercicios;

  root.innerHTML = `
    <div class="tabs">
      ${ejes.map(e => `<button class="tab-btn ${ejerciciosFiltro.eje===e.key?'active':''}" data-eje="${e.key}">${e.label}</button>`).join('')}
    </div>
    <div class="filter-row" id="filterRow">
      <button class="filter-chip ${!ejerciciosFiltro.valor?'active':''}" data-valor="">Todos</button>
      ${valoresDelEje.map(v => `<button class="filter-chip ${ejerciciosFiltro.valor===v?'active':''}" data-valor="${escapeHtml(v)}">${escapeHtml(v)}</button>`).join('')}
    </div>
    <div id="exerciseList">
      ${filtrados.length===0 ? `<div class="empty-state card"><h3>No hay ejercicios con ese filtro</h3></div>` : filtrados.map(ex => `
        <div class="exercise-card">
          <div>
            <div class="exercise-name">${escapeHtml(ex.nombre)}</div>
            ${ex.desc ? `<div class="exercise-desc">${escapeHtml(ex.desc)}</div>` : ''}
            <div class="exercise-tags">
              ${(ex.zona||[]).map(v=>`<span class="tag">${escapeHtml(v)}</span>`).join('')}
              ${(ex.articulacion||[]).map(v=>`<span class="tag" style="background:var(--sage-tint);color:#2f6b46;">${escapeHtml(v)}</span>`).join('')}
              ${(ex.musculo||[]).map(v=>`<span class="tag" style="background:var(--amber-tint);color:#8f6315;">${escapeHtml(v)}</span>`).join('')}
              ${(ex.gesto||[]).map(v=>`<span class="tag" style="background:var(--terra-tint);color:#8c2f26;">${escapeHtml(v)}</span>`).join('')}
            </div>
          </div>
          <button class="btn btn-sm btn-danger" data-action="del-ej" data-id="${ex.id}">Eliminar</button>
        </div>
      `).join('')}
    </div>
  `;

  root.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      ejerciciosFiltro = { eje: btn.dataset.eje, valor: null };
      renderEjercicios();
    });
  });
  root.querySelectorAll('.filter-chip').forEach(btn => {
    btn.addEventListener('click', () => {
      ejerciciosFiltro.valor = btn.dataset.valor || null;
      renderEjercicios();
    });
  });
  root.querySelectorAll('[data-action="del-ej"]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.ejercicios = state.ejercicios.filter(e => e.id !== btn.dataset.id);
      saveState(); renderEjercicios(); toast('Ejercicio eliminado');
    });
  });

  document.getElementById('btnNuevoEjercicio').addEventListener('click', abrirModalNuevoEjercicio);
}

function abrirModalNuevoEjercicio(){
  openModal(`
    <div class="modal-head"><h3>Agregar ejercicio</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="field"><label>Nombre *</label><input type="text" id="nx_nombre" placeholder="Ej: Sentadilla búlgara"></div>
      <div class="field"><label>Descripción</label><textarea id="nx_desc" placeholder="Indicación breve de ejecución"></textarea></div>
      <div class="grid-2">
        <div class="field"><label>Zona <span class="field-hint">(separar por comas)</span></label><input type="text" id="nx_zona" placeholder="Ej: Miembro inferior"></div>
        <div class="field"><label>Articulación</label><input type="text" id="nx_artic" placeholder="Ej: Cadera, Rodilla"></div>
      </div>
      <div class="grid-2">
        <div class="field"><label>Músculo</label><input type="text" id="nx_musc" placeholder="Ej: Glúteo medio"></div>
        <div class="field"><label>Gesto</label><input type="text" id="nx_gesto" placeholder="Ej: Control de equilibrio"></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="nx_guardar">Guardar ejercicio</button></div>
  `);
  document.getElementById('nx_guardar').addEventListener('click', () => {
    const nombre = document.getElementById('nx_nombre').value.trim();
    if(!nombre){ toast('El nombre es obligatorio', true); return; }
    const splitCsv = (str) => str.split(',').map(s=>s.trim()).filter(Boolean);
    state.ejercicios.push({
      id: uid('ex'),
      nombre,
      desc: document.getElementById('nx_desc').value.trim(),
      zona: splitCsv(document.getElementById('nx_zona').value),
      articulacion: splitCsv(document.getElementById('nx_artic').value),
      musculo: splitCsv(document.getElementById('nx_musc').value),
      gesto: splitCsv(document.getElementById('nx_gesto').value),
    });
    saveState(); closeModal(); renderEjercicios();
    toast('Ejercicio agregado a la biblioteca');
  });
}

/* =====================================================================
   VISTA: RUTINA DEL PACIENTE
   ===================================================================== */
function renderRutina(){
  const p = getActivePatient();
  if(!p) return;
  setTopbarActions(`<button class="btn btn-primary" id="btnAgregarARutina">+ Agregar ejercicio</button>`);
  const root = document.getElementById('view-rutina');

  if(p.rutina.length === 0){
    root.innerHTML = `<div class="empty-state card">
      <h3>Rutina vacía</h3>
      <p>Agregá ejercicios desde la biblioteca para armar la rutina de ${escapeHtml(p.nombre)}.</p>
    </div>`;
  }else{
    root.innerHTML = p.rutina.map((item, idx) => {
      const ex = state.ejercicios.find(e => e.id === item.ejercicioId);
      if(!ex) return '';
      return `
      <div class="routine-block">
        <div class="routine-block-head">
          <div>
            <div class="exercise-name">${escapeHtml(ex.nombre)}</div>
            <div class="exercise-tags">
              ${(ex.zona||[]).map(v=>`<span class="tag">${escapeHtml(v)}</span>`).join('')}
              ${(ex.articulacion||[]).map(v=>`<span class="tag" style="background:var(--sage-tint);color:#2f6b46;">${escapeHtml(v)}</span>`).join('')}
            </div>
          </div>
          <div style="display:flex;gap:6px;">
            <button class="btn btn-sm" data-action="edit-rut" data-idx="${idx}">Editar</button>
            <button class="btn btn-sm btn-danger" data-action="del-rut" data-idx="${idx}">Quitar</button>
          </div>
        </div>
        <div class="routine-meta">
          <span><strong class="mono">${item.series}</strong> series</span>
          <span><strong class="mono">${item.reps}</strong> reps</span>
          ${item.carga ? `<span><strong class="mono">${escapeHtml(item.carga)}</strong> carga</span>` : ''}
        </div>
        ${item.notas ? `<div class="field-hint" style="margin-top:6px;">${escapeHtml(item.notas)}</div>` : ''}
      </div>`;
    }).join('');
  }

  root.querySelectorAll('[data-action="del-rut"]').forEach(btn => {
    btn.addEventListener('click', () => {
      p.rutina.splice(Number(btn.dataset.idx),1);
      saveState(); renderRutina(); toast('Ejercicio quitado de la rutina');
    });
  });
  root.querySelectorAll('[data-action="edit-rut"]').forEach(btn => {
    btn.addEventListener('click', () => abrirModalEditarItemRutina(p, Number(btn.dataset.idx)));
  });

  document.getElementById('btnAgregarARutina').addEventListener('click', () => abrirModalElegirEjercicioParaRutina(p));
}

let rutinaFiltro = { eje:'zona', valor:null };

function abrirModalElegirEjercicioParaRutina(p){
  rutinaFiltro = { eje:'zona', valor:null };
  renderModalSelectorEjercicios(p);
}

function renderModalSelectorEjercicios(p){
  const ejes = [
    {key:'zona', label:'Zona'},{key:'articulacion', label:'Articulación'},
    {key:'musculo', label:'Músculo'},{key:'gesto', label:'Gesto'},
  ];
  const valoresDelEje = getEjesUnicos(rutinaFiltro.eje);
  if(rutinaFiltro.valor && !valoresDelEje.includes(rutinaFiltro.valor)) rutinaFiltro.valor = null;
  const filtrados = rutinaFiltro.valor
    ? state.ejercicios.filter(ex => (ex[rutinaFiltro.eje]||[]).includes(rutinaFiltro.valor))
    : state.ejercicios;

  openModal(`
    <div class="modal-head"><h3>Elegir ejercicio de la biblioteca</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="tabs" id="modalTabs">
        ${ejes.map(e => `<button class="tab-btn ${rutinaFiltro.eje===e.key?'active':''}" data-eje="${e.key}">${e.label}</button>`).join('')}
      </div>
      <div class="filter-row" id="modalFilterRow">
        <button class="filter-chip ${!rutinaFiltro.valor?'active':''}" data-valor="">Todos</button>
        ${valoresDelEje.map(v => `<button class="filter-chip ${rutinaFiltro.valor===v?'active':''}" data-valor="${escapeHtml(v)}">${escapeHtml(v)}</button>`).join('')}
      </div>
      <div style="max-height:320px;overflow-y:auto;">
        ${filtrados.length===0 ? '<p class="field-hint">No hay ejercicios con ese filtro.</p>' : filtrados.map(ex => `
          <div class="exercise-card" style="cursor:pointer;" data-action="elegir-ej" data-id="${ex.id}">
            <div>
              <div class="exercise-name">${escapeHtml(ex.nombre)}</div>
              ${ex.desc?`<div class="exercise-desc">${escapeHtml(ex.desc)}</div>`:''}
            </div>
            <button class="btn btn-sm btn-primary">Elegir</button>
          </div>
        `).join('')}
      </div>
    </div>
  `);

  document.querySelectorAll('#modalTabs .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => { rutinaFiltro = {eje:btn.dataset.eje, valor:null}; renderModalSelectorEjercicios(p); });
  });
  document.querySelectorAll('#modalFilterRow .filter-chip').forEach(btn => {
    btn.addEventListener('click', () => { rutinaFiltro.valor = btn.dataset.valor || null; renderModalSelectorEjercicios(p); });
  });
  document.querySelectorAll('[data-action="elegir-ej"]').forEach(card => {
    card.addEventListener('click', () => abrirModalConfigurarItemRutina(p, card.dataset.id));
  });
}

function abrirModalConfigurarItemRutina(p, ejercicioId, existingIdx=null){
  const ex = state.ejercicios.find(e => e.id === ejercicioId);
  const existing = existingIdx!==null ? p.rutina[existingIdx] : null;
  const valSeries = existing && existing.series !== undefined ? existing.series : 3;
  const valReps = existing && existing.reps !== undefined ? existing.reps : 12;
  const valCarga = existing ? (existing.carga||'') : '';
  const valNotas = existing ? (existing.notas||'') : '';
  openModal(`
    <div class="modal-head"><h3>${escapeHtml(ex.nombre)}</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="grid-3">
        <div class="field"><label>Series</label><input type="number" id="rt_series" value="${valSeries}"></div>
        <div class="field"><label>Repeticiones</label><input type="number" id="rt_reps" value="${valReps}"></div>
        <div class="field"><label>Carga</label><input type="text" id="rt_carga" value="${escapeHtml(valCarga)}" placeholder="Ej: 4kg"></div>
      </div>
      <div class="field"><label>Notas para el paciente</label><textarea id="rt_notas">${escapeHtml(valNotas)}</textarea></div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="rt_guardar">${existing?'Guardar cambios':'Agregar a la rutina'}</button></div>
  `);
  document.getElementById('rt_guardar').addEventListener('click', () => {
    const item = {
      ejercicioId,
      series: Number(document.getElementById('rt_series').value)||0,
      reps: Number(document.getElementById('rt_reps').value)||0,
      carga: document.getElementById('rt_carga').value.trim(),
      notas: document.getElementById('rt_notas').value.trim(),
    };
    if(existingIdx!==null) p.rutina[existingIdx] = item;
    else p.rutina.push(item);
    saveState(); closeModal(); renderRutina();
    toast(existing?'Ejercicio actualizado':'Ejercicio agregado a la rutina');
  });
}

function abrirModalEditarItemRutina(p, idx){
  abrirModalConfigurarItemRutina(p, p.rutina[idx].ejercicioId, idx);
}

/* =====================================================================
   VISTA: SESIONES
   ===================================================================== */
function renderSesiones(){
  const p = getActivePatient();
  if(!p) return;
  setTopbarActions(`<button class="btn btn-primary" id="btnNuevaSesion">+ Registrar sesión</button>`);
  const root = document.getElementById('view-sesiones');

  if(p.sesiones.length === 0){
    root.innerHTML = `<div class="empty-state card">
      <h3>Sin sesiones registradas</h3>
      <p>Registrá cada sesión para llevar el historial de tratamiento de ${escapeHtml(p.nombre)}.</p>
    </div>`;
  }else{
    const ordenadas = [...p.sesiones].sort((a,b)=> new Date(b.fecha)-new Date(a.fecha));
    root.innerHTML = ordenadas.map((s) => {
      const idxOriginal = p.sesiones.findIndex(x => x.id === s.id);
      return `
      <div class="card section-gap">
        <div class="card-head">
          <div>
            <h3>Sesión del ${fmtDate(s.fecha)}</h3>
            ${s.dolorSesion!==null && s.dolorSesion!==undefined ? `<span class="badge badge-amber" style="margin-top:6px;">Dolor en sesión: ${s.dolorSesion}/10</span>` : ''}
          </div>
          <button class="btn btn-sm btn-danger" data-action="del-ses" data-idx="${idxOriginal}">Eliminar</button>
        </div>
        <div class="card-pad">
          ${s.ejerciciosRealizados.length>0 ? `
            <div class="exercise-tags" style="margin-bottom:10px;">
              ${s.ejerciciosRealizados.map(id => {
                const ex = state.ejercicios.find(e=>e.id===id);
                return ex ? `<span class="tag">${escapeHtml(ex.nombre)}</span>` : '';
              }).join('')}
            </div>` : ''}
          ${s.notas ? `<p style="font-size:13.5px;">${escapeHtml(s.notas)}</p>` : '<p class="field-hint">Sin notas adicionales.</p>'}
        </div>
      </div>`;
    }).join('');
  }

  root.querySelectorAll('[data-action="del-ses"]').forEach(btn => {
    btn.addEventListener('click', () => {
      p.sesiones.splice(Number(btn.dataset.idx),1);
      saveState(); renderSesiones(); toast('Sesión eliminada');
    });
  });

  document.getElementById('btnNuevaSesion').addEventListener('click', () => abrirModalNuevaSesion(p));
}

function abrirModalNuevaSesion(p){
  openModal(`
    <div class="modal-head"><h3>Registrar sesión</h3><button class="modal-close" data-close>&times;</button></div>
    <div class="modal-body">
      <div class="field"><label>Fecha</label><input type="date" id="ss_fecha" value="${todayISO()}"></div>
      <div class="field">
        <label>Ejercicios realizados ${p.rutina.length===0?'<span class="field-hint">(la rutina está vacía)</span>':''}</label>
        <div class="checklist">
          ${p.rutina.map(item => {
            const ex = state.ejercicios.find(e=>e.id===item.ejercicioId);
            return ex ? `<label><input type="checkbox" value="${ex.id}" checked> ${escapeHtml(ex.nombre)}</label>` : '';
          }).join('') || '<span class="field-hint" style="padding:6px;">Agregá ejercicios a la rutina primero.</span>'}
        </div>
      </div>
      <div class="field">
        <label>Dolor durante la sesión (0-10, opcional): <span id="ss_dolor_display">—</span></label>
        <input type="range" min="0" max="10" id="ss_dolor" value="" style="width:100%;">
      </div>
      <div class="field"><label>Notas de la sesión</label><textarea id="ss_notas" placeholder="Evolución, tolerancia, observaciones..."></textarea></div>
    </div>
    <div class="modal-foot"><button class="btn" data-close>Cancelar</button><button class="btn btn-primary" id="ss_guardar">Guardar sesión</button></div>
  `);

  const sliderDolor = document.getElementById('ss_dolor');
  sliderDolor.addEventListener('input', () => {
    document.getElementById('ss_dolor_display').textContent = sliderDolor.value;
  });

  document.getElementById('ss_guardar').addEventListener('click', () => {
    const ejerciciosRealizados = Array.from(document.querySelectorAll('.checklist input:checked')).map(i=>i.value);
    p.sesiones.push({
      id: uid('ses'),
      fecha: document.getElementById('ss_fecha').value || todayISO(),
      ejerciciosRealizados,
      dolorSesion: sliderDolor.value ? Number(sliderDolor.value) : null,
      notas: document.getElementById('ss_notas').value.trim(),
    });
    saveState(); closeModal(); renderSesiones();
    toast('Sesión registrada');
  });
}

/* =====================================================================
   MODAL GENÉRICO
   ===================================================================== */
function openModal(html){
  document.getElementById('modalBox').innerHTML = html;
  document.getElementById('modalOverlay').hidden = false;
  document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', closeModal));
}
function closeModal(){
  document.getElementById('modalOverlay').hidden = true;
  document.getElementById('modalBox').innerHTML = '';
}
document.getElementById('modalOverlay').addEventListener('click', (e) => {
  if(e.target.id === 'modalOverlay') closeModal();
});
document.addEventListener('keydown', (e) => {
  if(e.key === 'Escape' && !document.getElementById('modalOverlay').hidden) closeModal();
});

/* =====================================================================
   EXPORT / IMPORT
   ===================================================================== */
function exportarDatos(){
  const data = JSON.stringify(state, null, 2);
  const blob = new Blob([data], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `consultorio-backup-${todayISO()}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  toast('Datos exportados');
}

function importarDatos(file){
  const reader = new FileReader();
  reader.onload = (e) => {
    try{
      const parsed = JSON.parse(e.target.result);
      if(!parsed.pacientes){ throw new Error('Formato inválido'); }
      state.pacientes = parsed.pacientes || [];
      state.ejercicios = parsed.ejercicios && parsed.ejercicios.length ? parsed.ejercicios : EJERCICIOS_EJEMPLO;
      state.activePatientId = parsed.activePatientId || null;
      saveState();
      refreshSidebarPatient();
      toast('Datos importados correctamente');
      goToView('pacientes');
    }catch(err){
      toast('No se pudo importar el archivo: formato inválido', true);
    }
  };
  reader.readAsText(file);
}

/* =====================================================================
   EVENTOS GLOBALES E INICIALIZACIÓN
   ===================================================================== */
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => goToView(btn.dataset.view));
});

document.getElementById('btnExport').addEventListener('click', exportarDatos);
document.getElementById('btnImport').addEventListener('click', () => document.getElementById('fileImport').click());
document.getElementById('fileImport').addEventListener('change', (e) => {
  if(e.target.files[0]) importarDatos(e.target.files[0]);
  e.target.value = '';
});

document.getElementById('menuToggle').addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('open');
});

function init(){
  loadState();
  refreshSidebarPatient();
  const startView = (location.hash || '').replace('#','') || 'pacientes';
  goToView(VIEWS.includes(startView) ? startView : 'pacientes');
}

init();
